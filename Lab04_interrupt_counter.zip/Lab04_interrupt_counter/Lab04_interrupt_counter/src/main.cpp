/*
 * LAB 04 - Ngắt ngoài (interrupt) + đếm số, nhấn giữ (long press)
 * BTN1 GPIO4: +1   | BTN2 GPIO5: -1   | BTN3 GPIO6: nhấn giữ 2 s để reset
 * LED GPIO17 nháy đúng bằng giá trị bộ đếm mỗi khi bộ đếm thay đổi.
 */


#include <Arduino.h>
#include <Preferences.h>

#define LED_PIN 17
#define BTN_UP 4
#define BTN_DOWN 5
#define BTN_RST 6

Preferences preferences;

// ISR chi danh dau co su kien
volatile bool upInterrupt = false;
volatile bool downInterrupt = false;

void IRAM_ATTR isrUp() {
  upInterrupt = true;
}

void IRAM_ATTR isrDown() {
  downInterrupt = true;
}

// Timer phan mem chong doi
const unsigned long DEBOUNCE_MS = 40;

struct ButtonState {
  uint8_t pin;
  bool lastReading;
  bool stableState;
  unsigned long changedAt;
};

ButtonState upButton = {BTN_UP, HIGH, HIGH, 0};
ButtonState downButton = {BTN_DOWN, HIGH, HIGH, 0};
ButtonState resetButton = {BTN_RST, HIGH, HIGH, 0};

// Bo dem
int counter = 0;

// Nhan giu +1 de tu tang
const unsigned long HOLD_START_MS = 1000;
const unsigned long AUTO_REPEAT_MS = 200;

unsigned long upPressStart = 0;
unsigned long lastAutoRepeat = 0;
bool autoRepeatStarted = false;

// Nhan giu reset
const unsigned long RESET_HOLD_MS = 2000;
unsigned long resetPressStart = 0;
bool resetHandled = false;

// LED nhap nhay
int blinksLeft = 0;
unsigned long blinkT = 0;
bool blinkOn = false;

// Doc nut va chong doi bang millis()
// Tra ve true neu trang thai on dinh thay doi
bool updateButton(ButtonState &btn,
                  unsigned long now) {
  bool reading = digitalRead(btn.pin);

  if (reading != btn.lastReading) {
    btn.changedAt = now;
    btn.lastReading = reading;
  }

  if (now - btn.changedAt >= DEBOUNCE_MS &&
      reading != btn.stableState) {
    btn.stableState = reading;
    return true;
  }

  return false;
}

void startBlink(int n) {
  blinksLeft = n;
  blinkT = millis();
  blinkOn = false;
  digitalWrite(LED_PIN, LOW);
}

void updateBlink(unsigned long now) {
  if (blinksLeft <= 0) return;

  if (now - blinkT >= 200) {
    blinkT = now;
    blinkOn = !blinkOn;
    digitalWrite(LED_PIN, blinkOn);

    if (!blinkOn) {
      blinksLeft--;
    }
  }
}

// Cap nhat bo dem va luu NVS
void changeCounter(int delta) {
  int newValue = counter + delta;

  if (newValue < 0) {
    newValue = 0;
  }

  if (newValue == counter) return;

  counter = newValue;

  Serial.printf("Bo dem = %d\n", counter);

  size_t written =
      preferences.putInt("counter", counter);

  int readBack =
      preferences.getInt("counter", -1);

  Serial.printf(
    "NVS: %s | Doc lai = %d\n",
    written == sizeof(int) ? "OK" : "LOI",
    readBack
  );

  startBlink(min(counter, 10));
}

void resetCounter() {
  counter = 0;

  size_t written =
      preferences.putInt("counter", 0);

  Serial.println("RESET bo dem ve 0");
  Serial.printf("Luu NVS: %s\n",
    written == sizeof(int) ? "OK" : "LOI");

  startBlink(3);
}

void setup() {
  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  pinMode(BTN_UP, INPUT_PULLUP);
  pinMode(BTN_DOWN, INPUT_PULLUP);
  pinMode(BTN_RST, INPUT_PULLUP);

  preferences.begin("lab04", false);

  counter = preferences.getInt("counter", 0);
  if (counter < 0) counter = 0;

  Serial.println("LAB 04 - MO RONG 1 + 2 + 3");
  Serial.printf("Khoi phuc bo dem = %d\n",
                counter);

  Serial.println("BTN +1: tang");
  Serial.println("Giu +1: tu dong tang");
  Serial.println("BTN -1: giam");
  Serial.println("Giu RST > 2s: reset");

  attachInterrupt(
    digitalPinToInterrupt(BTN_UP),
    isrUp,
    FALLING
  );

  attachInterrupt(
    digitalPinToInterrupt(BTN_DOWN),
    isrDown,
    FALLING
  );
}

void loop() {
  unsigned long now = millis();

  // Lay co ngat an toan
  noInterrupts();
  bool upEvent = upInterrupt;
  bool downEvent = downInterrupt;
  upInterrupt = false;
  downInterrupt = false;
  interrupts();

  // Khong xu ly nut trong ISR.
  // Co ngat duoc ghi nhan, con timer phan mem
  // xac nhan trang thai nut trong loop().
  (void)upEvent;
  (void)downEvent;

  // ===== NUT +1 =====
  if (updateButton(upButton, now)) {
    if (upButton.stableState == LOW) {
      changeCounter(1);

      upPressStart = now;
      lastAutoRepeat = now;
      autoRepeatStarted = false;
    } else {
      upPressStart = 0;
      autoRepeatStarted = false;
    }
  }

  // Giu +1 de tang lien tuc
  if (upButton.stableState == LOW) {
    if (!autoRepeatStarted &&
        now - upPressStart >= HOLD_START_MS) {

      autoRepeatStarted = true;
      lastAutoRepeat = now;

      changeCounter(1);
      Serial.println("AUTO INCREMENT BAT");
    }

    if (autoRepeatStarted &&
        now - lastAutoRepeat >= AUTO_REPEAT_MS) {

      lastAutoRepeat = now;
      changeCounter(1);
    }
  }

  // ===== NUT -1 =====
  if (updateButton(downButton, now)) {
    if (downButton.stableState == LOW) {
      changeCounter(-1);
    }
  }

  // ===== NUT RESET =====
  if (updateButton(resetButton, now)) {
    if (resetButton.stableState == LOW) {
      resetPressStart = now;
      resetHandled = false;
    } else {
      resetPressStart = 0;
      resetHandled = false;
    }
  }

  if (resetButton.stableState == LOW &&
      !resetHandled &&
      now - resetPressStart >= RESET_HOLD_MS) {

    resetHandled = true;
    resetCounter();
  }

  updateBlink(now);
}

