# Lab 04 – Ngắt ngoài, bộ đếm và nhấn giữ

*Phần 1 – GPIO & ngoại vi cơ bản* · Board: **ESP32-S3-DevKitC-1** (Wokwi + PlatformIO)

## Mục tiêu

Sử dụng ngắt ngoài `attachInterrupt`, biến `volatile`, vùng tới hạn; phân biệt nhấn ngắn / nhấn giữ.

## Linh kiện & sơ đồ nối chân

| Linh kiện | Chân linh kiện | Nối tới ESP32-S3 |
|---|---|---|
| LED red (led1) | Anode (qua R 220Ω) | GPIO17 |
| Nút nhấn +1 | 1 / 2 | GPIO4 / GND (INPUT_PULLUP) |
| Nút nhấn -1 | 1 / 2 | GPIO5 / GND (INPUT_PULLUP) |
| Nút nhấn RST | 1 / 2 | GPIO6 / GND (INPUT_PULLUP) |

Nguồn: VCC → `3V3`, GND → `GND` (đã nối sẵn trong `diagram.json`).

## Cách chạy

1. Mở thư mục lab này bằng VS Code (đã cài PlatformIO IDE và Wokwi Simulator).
2. `PlatformIO: Build` (hoặc `pio run`).
3. `F1 → Wokwi: Start Simulator` – Wokwi đọc `wokwi.toml` và `diagram.json`.

## Kiến thức chính

Hàm ISR phải ngắn, đặt trong IRAM (`IRAM_ATTR`), không dùng `Serial`. Biến dùng chung giữa ISR và `loop()` cần `volatile` và đọc trong vùng `noInterrupts()/interrupts()`.

## Thử nghiệm trên Wokwi

Nhấn +1/-1 xem giá trị trên Serial, LED nháy đúng số lần; giữ RST 2 s để về 0.

## Bài tập mở rộng

1. Lưu giá trị bộ đếm vào `Preferences` (như project mẫu lưu WiFi) để giữ qua reset.
2. Thay ISR debounce bằng timer phần mềm.
3. Nhấn giữ +1 thì tự tăng nhanh (auto-repeat).
