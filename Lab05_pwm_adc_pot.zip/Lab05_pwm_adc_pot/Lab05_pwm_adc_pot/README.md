# Lab 05 – PWM (LEDC) + ADC biến trở

*Phần 1 – GPIO & ngoại vi cơ bản* · Board: **ESP32-S3-DevKitC-1** (Wokwi + PlatformIO)

## Mục tiêu

Đọc ADC 12 bit, điều chế độ rộng xung bằng bộ LEDC của ESP32.

## Linh kiện & sơ đồ nối chân

| Linh kiện | Chân linh kiện | Nối tới ESP32-S3 |
|---|---|---|
| LED red (led1) | Anode (qua R 220Ω) | GPIO17 |
| Biến trở | SIG | GPIO1 (ADC1) |
| Nút nhấn MODE | 1 / 2 | GPIO4 / GND (INPUT_PULLUP) |

Nguồn: VCC → `3V3`, GND → `GND` (đã nối sẵn trong `diagram.json`).

## Cách chạy

1. Mở thư mục lab này bằng VS Code (đã cài PlatformIO IDE và Wokwi Simulator).
2. `PlatformIO: Build` (hoặc `pio run`).
3. `F1 → Wokwi: Start Simulator` – Wokwi đọc `wokwi.toml` và `diagram.json`.

## Kiến thức chính

ESP32-S3 có ADC1 (GPIO1–10) và ADC2 (GPIO11–20); khi bật WiFi chỉ ADC1 dùng được. LEDC: `ledcSetup(kênh, tần số, độ phân giải)` + `ledcAttachPin` (API Arduino-ESP32 2.x mà PlatformIO đang dùng).

## Thử nghiệm trên Wokwi

Xoay biến trở → LED sáng/tối theo; Serial in ADC, điện áp, duty. Nhấn MODE để LED tự “thở”.

## Bài tập mở rộng

1. Dùng thang đo gamma (duty = x^2.2) để độ sáng tuyến tính với mắt người.
2. Lọc nhiễu ADC bằng trung bình trượt 8 mẫu.
3. Đổi độ phân giải 8/10/13 bit, so sánh.
