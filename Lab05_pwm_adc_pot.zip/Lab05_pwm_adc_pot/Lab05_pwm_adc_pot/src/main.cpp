/*
 * LAB 05 - PWM (LEDC) điều chỉnh độ sáng LED + đọc ADC biến trở
 * Biến trở: GPIO1 (ADC1). LED: GPIO17. Nút GPIO4: chuyển chế độ MANUAL <-> AUTO FADE.
 * Lưu ý: ESP32-S3 + WiFi chỉ dùng được ADC1 (GPIO1..10) -> tập thói quen ngay từ đầu.
 */
#include <Arduino.h>
#include <math.h>

#define LED_PIN 17
#define POT_PIN 1
#define BTN_PIN 4

const uint32_t PWM_FREQ = 1000;
const uint8_t PWM_BITS[] = {8, 10, 13};
const int NUM_MODES = 3;
int resolutionIndex = 1;  // Bat dau 10 bit

const float GAMMA = 2.2f;
const int ADC_SAMPLES = 8;
int adcBuffer[ADC_SAMPLES] = {0};
int adcIndex = 0;
long adcSum = 0;

bool autoMode = false;
float fadeLevel = 0.0f;
int fadeDirection = 1;

// Nut MODE debounce + long press
bool lastReading = HIGH;
bool stableButton = HIGH;
unsigned long lastChange = 0;
unsigned long pressStart = 0;
bool longPressHandled = false;

const unsigned long DEBOUNCE_MS = 40;
const unsigned long LONG_PRESS_MS = 2000;

// Chu ky cap nhat
unsigned long lastUpdate = 0;
unsigned long lastPrint = 0;

int pwmMax() {
  return (1 << PWM_BITS[resolutionIndex]) - 1;
}

// Gamma correction: 0..1 -> duty PWM
int gammaDuty(float brightness) {
  brightness = constrain(brightness, 0.0f, 1.0f);

  float corrected = powf(brightness, GAMMA);

  return (int)roundf(corrected * pwmMax());
}

// Loc trung binh truot 8 mau
float readFilteredADC() {
  int raw = analogRead(POT_PIN);

  adcSum -= adcBuffer[adcIndex];
  adcBuffer[adcIndex] = raw;
  adcSum += raw;

  adcIndex = (adcIndex + 1) % ADC_SAMPLES;

  return (float)adcSum / ADC_SAMPLES;
}

void configurePWM() {
  // API Arduino-ESP32 3.x
  ledcDetach(LED_PIN);

  bool ok = ledcAttach(
    LED_PIN,
    PWM_FREQ,
    PWM_BITS[resolutionIndex]
  );

  if (ok) {
    Serial.printf(
      "PWM: %d bit | Duty max: %d\n",
      PWM_BITS[resolutionIndex],
      pwmMax()
    );
  } else {
    Serial.println("LOI: Khong khoi tao duoc PWM");
  }
}

void handleButton(unsigned long now) {
  bool reading = digitalRead(BTN_PIN);

  if (reading != lastReading) {
    lastChange = now;
    lastReading = reading;
  }

  if (now - lastChange >= DEBOUNCE_MS &&
      reading != stableButton) {

    stableButton = reading;

    if (stableButton == LOW) {
      pressStart = now;
      longPressHandled = false;
    } else {
      // Nhan ngan: doi MANUAL / AUTO FADE
      if (!longPressHandled) {
        autoMode = !autoMode;

        Serial.printf(
          "Che do: %s\n",
          autoMode ? "AUTO FADE" : "MANUAL"
        );
      }
    }
  }

  // Giu MODE 2 giay: doi do phan giai
  if (stableButton == LOW &&
      !longPressHandled &&
      now - pressStart >= LONG_PRESS_MS) {

    longPressHandled = true;

    resolutionIndex =
      (resolutionIndex + 1) % NUM_MODES;

    configurePWM();
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(BTN_PIN, INPUT_PULLUP);

  analogReadResolution(12);

  // Khoi tao bo loc bang gia tri ADC ban dau
  int initialADC = analogRead(POT_PIN);

  for (int i = 0; i < ADC_SAMPLES; i++) {
    adcBuffer[i] = initialADC;
    adcSum += initialADC;
  }

  bool ok = ledcAttach(
    LED_PIN,
    PWM_FREQ,
    PWM_BITS[resolutionIndex]
  );

  Serial.println("LAB 05 - MO RONG 1 + 2 + 3");
  Serial.println("Xoay bien tro: dieu chinh LED");
  Serial.println("Nhan MODE: MANUAL / AUTO FADE");
  Serial.println("Giu MODE 2s: doi PWM 8/10/13 bit");

  if (!ok) {
    Serial.println("LOI: Khoi tao PWM that bai");
  }

  Serial.printf(
    "PWM ban dau: %d bit\n",
    PWM_BITS[resolutionIndex]
  );
}

void loop() {
  unsigned long now = millis();

  handleButton(now);

  if (now - lastUpdate < 20) return;
  lastUpdate = now;

  float adcFiltered = readFilteredADC();
  float brightness;

  if (autoMode) {
    // LED tu sang dan, toi dan
    fadeLevel += fadeDirection * 0.008f;

    if (fadeLevel >= 1.0f) {
      fadeLevel = 1.0f;
      fadeDirection = -1;
    } else if (fadeLevel <= 0.0f) {
      fadeLevel = 0.0f;
      fadeDirection = 1;
    }

    brightness = fadeLevel;
  } else {
    brightness = adcFiltered / 4095.0f;
  }

  int duty = gammaDuty(brightness);

  ledcWrite(LED_PIN, duty);

  if (now - lastPrint >= 500) {
    lastPrint = now;

    Serial.printf(
      "MODE=%s | ADC=%.0f | V=%.2f | "
      "PWM=%d bit | duty=%d/%d | %d%%\n",
      autoMode ? "AUTO" : "MANUAL",
      adcFiltered,
      adcFiltered * 3.3f / 4095.0f,
      PWM_BITS[resolutionIndex],
      duty,
      pwmMax(),
      (int)roundf(brightness * 100)
    );
  }
}
