/*
 * LAB 01 - Nháy LED không chặn (non-blocking) bằng millis()
 * Board : ESP32-S3-DevKitC-1 (Wokwi)
 * Kế thừa: LED_PIN 17 giống project mẫu.
 */

#include <Arduino.h>

#define LED_PIN 17

const unsigned long ON_TIME = 200;
const unsigned long OFF_TIME = 800;

unsigned long lastToggle = 0;
bool ledState = false;

void setup() {
  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Serial.println("Lab 01 - Blink 200ms ON, 800ms OFF");
}

void loop() {
  unsigned long now = millis();

  unsigned long interval = ledState
                             ? ON_TIME
                             : OFF_TIME;

  if (now - lastToggle >= interval) {
    lastToggle = now;
    ledState = !ledState;

    digitalWrite(LED_PIN, ledState ? HIGH : LOW);

    Serial.printf("[%lu ms] LED %s\n",
                  now,
                  ledState ? "ON" : "OFF");
  }
}
