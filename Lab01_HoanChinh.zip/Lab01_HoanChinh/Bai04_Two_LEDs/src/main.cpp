/*
 * LAB 01 - Nháy LED không chặn (non-blocking) bằng millis()
 * Board : ESP32-S3-DevKitC-1 (Wokwi)
 * Kế thừa: LED_PIN 17 giống project mẫu.
 */

/*
 * LAB 01 - Two Independent LEDs using millis()
 * Board: ESP32-S3-DevKitC-1
 */

#include <Arduino.h>

#define LED_RED   17
#define LED_GREEN 18

const unsigned long RED_INTERVAL = 500;
const unsigned long GREEN_INTERVAL = 300;

unsigned long lastRed = 0;
unsigned long lastGreen = 0;

bool redState = false;
bool greenState = false;

void setup() {
  Serial.begin(115200);

  pinMode(LED_RED, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);

  digitalWrite(LED_RED, LOW);
  digitalWrite(LED_GREEN, LOW);

  Serial.println("Lab 01 - Two Independent LEDs");
}

void loop() {
  unsigned long now = millis();

  // LED do: 500 ms doi trang thai mot lan
  if (now - lastRed >= RED_INTERVAL) {
    lastRed = now;
    redState = !redState;

    digitalWrite(LED_RED, redState ? HIGH : LOW);

    Serial.printf("[%lu ms] RED %s\n",
                  now, redState ? "ON" : "OFF");
  }

  // LED xanh: 300 ms doi trang thai mot lan
  if (now - lastGreen >= GREEN_INTERVAL) {
    lastGreen = now;
    greenState = !greenState;

    digitalWrite(LED_GREEN, greenState ? HIGH : LOW);

    Serial.printf("[%lu ms] GREEN %s\n",
                  now, greenState ? "ON" : "OFF");
  }
}
