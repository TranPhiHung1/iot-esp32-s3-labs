# Lab 01 – Nháy LED không chặn với millis()

*Phần 1 – GPIO & ngoại vi cơ bản* · Board: **ESP32-S3-DevKitC-1** (Wokwi + PlatformIO)

## Mục tiêu

Làm quen cấu trúc project PlatformIO + Wokwi giống project mẫu; điều khiển GPIO ra; hiểu vì sao không nên dùng `delay()`.

## Linh kiện & sơ đồ nối chân

| Linh kiện | Chân linh kiện | Nối tới ESP32-S3 |
|---|---|---|
| LED red (led1) | Anode (qua R 220Ω) | GPIO17 |

Nguồn: VCC → `3V3`, GND → `GND` (đã nối sẵn trong `diagram.json`).

## Cách chạy

1. Mở thư mục lab này bằng VS Code (đã cài PlatformIO IDE và Wokwi Simulator).
2. `PlatformIO: Build` (hoặc `pio run`).
3. `F1 → Wokwi: Start Simulator` – Wokwi đọc `wokwi.toml` và `diagram.json`.

## Kiến thức chính

`millis()` trả về số ms kể từ khi khởi động. Phép so sánh `now - last >= INTERVAL` vẫn đúng khi `millis()` tràn số (sau ~49 ngày) nhờ số học không dấu. Nhờ không chặn, `loop()` vẫn có thể xử lý nút nhấn, web server... như `server.handleClient()` trong project mẫu.

## Thử nghiệm trên Wokwi

Chạy mô phỏng, quan sát LED đỏ nháy 1 Hz và log trên Serial Monitor.

## Bài tập mở rộng

1. Đổi chu kỳ sáng 200 ms / tắt 800 ms (duty khác nhau).
2. Nháy mã SOS (… --- …) không dùng `delay()`.
3. Thêm LED thứ hai nháy với chu kỳ khác, độc lập.
