/*
 * LAB 01 - Nháy LED không chặn (non-blocking) bằng millis()
 * Board : ESP32-S3-DevKitC-1 (Wokwi)
 * Kế thừa: LED_PIN 17 giống project mẫu.
 */

#include <Arduino.h>

#define LED_PIN 17

// LED doi trang thai sau moi 500 ms
const unsigned long BLINK_MS = 500;

unsigned long lastToggle = 0;
bool ledState = false;

void setup() {
  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Serial.println("Lab 01 - Blink LED using millis()");
}

void loop() {
  unsigned long now = millis();

  if (now - lastToggle >= BLINK_MS) {
    lastToggle = now;

    ledState = !ledState;
    digitalWrite(LED_PIN, ledState ? HIGH : LOW);

    Serial.printf("[%lu ms] LED %s\n",
                  now,
                  ledState ? "ON" : "OFF");
  }
}
