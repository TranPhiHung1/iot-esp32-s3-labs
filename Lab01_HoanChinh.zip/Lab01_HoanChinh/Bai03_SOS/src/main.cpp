/*
 * LAB 01 - Nháy LED không chặn (non-blocking) bằng millis()
 * Board : ESP32-S3-DevKitC-1 (Wokwi)
 * Kế thừa: LED_PIN 17 giống project mẫu.
 */

#include <Arduino.h>

#define LED_PIN 17

// 1 don vi Morse = 200 ms
const unsigned long UNIT = 200;

// SOS = ... --- ...
const char* morse = "...---...";

int indexMorse = 0;
bool ledState = false;

unsigned long lastChange = 0;
unsigned long interval = 0;

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Serial.println("Lab 01 - SOS using millis()");
}

void loop() {
  unsigned long now = millis();

  if (now - lastChange >= interval) {
    lastChange = now;

    if (!ledState) {
      // Bat LED
      ledState = true;

      char symbol = morse[indexMorse];
      interval = (symbol == '.') ? UNIT : 3 * UNIT;

      digitalWrite(LED_PIN, HIGH);
      
      if (indexMorse == 3 || indexMorse == 6) {
      Serial.print(" ");
      }
      
      Serial.print(symbol);
      

    } else {
      // Tat LED
      ledState = false;
      digitalWrite(LED_PIN, LOW);

      indexMorse++;

      if (indexMorse >= 9) {
        indexMorse = 0;
        interval = 7 * UNIT;
        Serial.println();
      } else if (indexMorse == 3 || indexMorse == 6) {
        interval = 3 * UNIT;
      } else {
        interval = UNIT;
      }

      
    }
  }
}
