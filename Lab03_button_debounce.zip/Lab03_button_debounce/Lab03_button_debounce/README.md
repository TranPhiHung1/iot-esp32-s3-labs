# Lab 03 – Nút nhấn bật/tắt LED có chống dội

*Phần 1 – GPIO & ngoại vi cơ bản* · Board: **ESP32-S3-DevKitC-1** (Wokwi + PlatformIO)

## Mục tiêu

Đọc ngõ vào số với `INPUT_PULLUP`, phát hiện cạnh nhấn, chống dội phím bằng phần mềm.

## Linh kiện & sơ đồ nối chân

| Linh kiện | Chân linh kiện | Nối tới ESP32-S3 |
|---|---|---|
| LED red (led1) | Anode (qua R 220Ω) | GPIO17 |
| Nút nhấn BTN1 | 1 / 2 | GPIO4 / GND (INPUT_PULLUP) |

Nguồn: VCC → `3V3`, GND → `GND` (đã nối sẵn trong `diagram.json`).

## Cách chạy

1. Mở thư mục lab này bằng VS Code (đã cài PlatformIO IDE và Wokwi Simulator).
2. `PlatformIO: Build` (hoặc `pio run`).
3. `F1 → Wokwi: Start Simulator` – Wokwi đọc `wokwi.toml` và `diagram.json`.

## Kiến thức chính

Tiếp điểm cơ khí rung trong vài ms tạo nhiều xung giả. Thuật toán: chỉ chấp nhận trạng thái mới khi nó giữ ổn định lâu hơn `DEBOUNCE_MS`. Với pull-up nội, nút không nhấn = HIGH, nhấn = LOW.

## Thử nghiệm trên Wokwi

Nhấn nút nhiều lần, mỗi lần nhấn LED đổi trạng thái đúng một lần.

## Bài tập mở rộng

1. Đặt `DEBOUNCE_MS = 0`, bật thuộc tính `bounce` của nút trên Wokwi để thấy hiện tượng dội.
2. Nhấn đúp (double-click) trong 400 ms để nháy LED nhanh.
3. Đóng gói logic thành `class Button`.
