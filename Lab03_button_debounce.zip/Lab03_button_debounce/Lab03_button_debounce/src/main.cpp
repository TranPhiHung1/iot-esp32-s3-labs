/*
 * LAB 03 - Nút nhấn bật/tắt LED có chống dội (debounce)
 * Nút: GPIO4 (INPUT_PULLUP, nhấn = LOW). LED: GPIO17.
 */


#include <Arduino.h>

#define LED_PIN 17
#define BUTTON_PIN 4

const unsigned long DEBOUNCE_MS = 40;
const unsigned long DOUBLE_CLICK_MS = 400;
const unsigned long BLINK_MS = 150;
const unsigned long FAST_BLINK_DURATION = 2000;

// =====================================
// CLASS BUTTON - CHONG DOI PHIM
// =====================================
class Button {
private:
  int pin;
  bool lastReading;
  bool stableState;
  unsigned long lastDebounceTime;
  unsigned long debounceMs;

public:
  Button(int buttonPin, unsigned long debounce = 40) {
    pin = buttonPin;
    debounceMs = debounce;
    lastReading = HIGH;
    stableState = HIGH;
    lastDebounceTime = 0;
  }

  void begin() {
    pinMode(pin, INPUT_PULLUP);
  }

  // Tra ve true khi phat hien nhan hop le
  bool wasPressed(unsigned long now) {
    bool reading = digitalRead(pin);

    if (reading != lastReading) {
      lastDebounceTime = now;
    }

    bool pressed = false;

    if (now - lastDebounceTime >= debounceMs) {
      if (reading != stableState) {
        stableState = reading;

        if (stableState == LOW) {
          pressed = true;
        }
      }
    }

    lastReading = reading;
    return pressed;
  }
};

// Tao doi tuong nut nhan
Button btn1(BUTTON_PIN, DEBOUNCE_MS);

// =====================================
// BIEN QUAN LY LED
// =====================================
bool ledState = false;

bool waitingSecondClick = false;
unsigned long firstClickTime = 0;

bool fastBlink = false;
unsigned long blinkStart = 0;
unsigned long lastBlink = 0;

unsigned long pressCount = 0;

// Xu ly su kien nhan nut
void handlePress(unsigned long now) {
  pressCount++;

  Serial.printf("Nhan lan %lu\n", pressCount);

  if (waitingSecondClick &&
      now - firstClickTime <= DOUBLE_CLICK_MS) {

    waitingSecondClick = false;
    fastBlink = true;

    blinkStart = now;
    lastBlink = now;

    Serial.println("PHAT HIEN NHAN DUP!");
    Serial.println("LED NHAP NHAY NHANH");

  } else {
    waitingSecondClick = true;
    firstClickTime = now;
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);
  btn1.begin();

  digitalWrite(LED_PIN, LOW);

  Serial.println("LAB 03 - CLASS BUTTON");
  Serial.println("Nhan don: LED bat/tat");
  Serial.println("Nhan dup: LED nhap nhay nhanh");
}

void loop() {
  unsigned long now = millis();

  // Doc nut thong qua class Button
  if (btn1.wasPressed(now)) {
    handlePress(now);
  }

  // Xu ly nhan don sau 400ms
  if (waitingSecondClick &&
      now - firstClickTime > DOUBLE_CLICK_MS) {

    waitingSecondClick = false;

    if (!fastBlink) {
      ledState = !ledState;
      digitalWrite(LED_PIN, ledState);

      Serial.println(ledState ?
        "NHAN DON -> LED BAT" :
        "NHAN DON -> LED TAT");
    }
  }

  // Xu ly LED nhap nhay nhanh
  if (fastBlink) {
    if (now - blinkStart >= FAST_BLINK_DURATION) {
      fastBlink = false;

      digitalWrite(LED_PIN, ledState);
      Serial.println("KET THUC NHAP NHAY");

    } else if (now - lastBlink >= BLINK_MS) {
      lastBlink = now;

      digitalWrite(LED_PIN,
                   !digitalRead(LED_PIN));
    }
  }
}

