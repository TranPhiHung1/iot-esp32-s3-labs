/*
 * LAB 07 - Buzzer: phát nốt nhạc, mini piano 3 phím, phát giai điệu
 * Buzzer GPIO18. BTN1 GPIO4 = Do, BTN2 GPIO5 = Mi, BTN3 GPIO6 = Sol.
 * Nhấn đồng thời BTN1 + BTN3 để phát bài "Happy Birthday".
 * giữ ctrl để nhấn được 2 nút để phát bài hpbd.
 */

#include <Arduino.h>

// LAB 07 - Mini Piano
// MR1: Phat nhac khong chan bang millis()
// MR2: Bien tro chuyen quang tam
// MR3: Ghi va phat lai chuoi not

#define BUZZER 18
#define POT_OCTAVE 1

const int BTN[3] = {4, 5, 6};
const int NOTE_FREQ[3] = {262, 330, 392};
const char* NOTE_NAME[3] = {"Do", "Mi", "Sol"};

const int MELODY[] = {
  262,262,294,262,349,330,0,
  262,262,294,262,392,349,0,
  262,262,523,440,349,330,294,0,
  466,466,440,349,392,349
};

const int DUR[] = {
  300,150,450,450,450,900,200,
  300,150,450,450,450,900,200,
  300,150,450,450,450,900,200,
  300,150,450,450,450,900
};

const int MELODY_LEN = sizeof(MELODY) / sizeof(MELODY[0]);
const unsigned long GAP_MS = 40;
const unsigned long DEBOUNCE_MS = 30;

// Phat giai dieu
enum PlayMode {
  PLAY_NONE,
  PLAY_BIRTHDAY,
  PLAY_RECORDED
};

PlayMode playMode = PLAY_NONE;
int melodyIndex = 0;
bool noteGap = false;
unsigned long noteStart = 0;

// Bien tro
int octaveShift = 0;
unsigned long lastOctaveCheck = 0;

// Ghi nho not
const int MAX_NOTES = 30;
int recordedNotes[MAX_NOTES];
int recordedCount = 0;
bool recording = false;
int replayIndex = 0;

// Nut nhan
bool rawPressed[3] = {false, false, false};
bool pressed[3] = {false, false, false};
bool previousPressed[3] = {false, false, false};
unsigned long lastChange[3] = {0, 0, 0};

int playingKey = -1;
int previousCombo = 0;

// 0 = khong, 1 = DO+MI, 2 = DO+SOL, 3 = MI+SOL
int getCombo() {
  if (pressed[0] && pressed[1]) return 1;
  if (pressed[0] && pressed[2]) return 2;
  if (pressed[1] && pressed[2]) return 3;
  return 0;
}

int shiftedFrequency(int frequency) {
  if (frequency <= 0) return 0;

  if (octaveShift == -1) return frequency / 2;
  if (octaveShift == 1) return frequency * 2;

  return frequency;
}

void updateOctave() {
  unsigned long now = millis();

  if (now - lastOctaveCheck < 100) return;
  lastOctaveCheck = now;

  int adc = analogRead(POT_OCTAVE);
  int newShift;

  if (adc < 1365) newShift = -1;
  else if (adc < 2730) newShift = 0;
  else newShift = 1;

  if (newShift != octaveShift) {
    octaveShift = newShift;

    Serial.printf(
      "Octave shift: %+d | ADC=%d\n",
      octaveShift, adc
    );

    if (playMode == PLAY_NONE && playingKey >= 0) {
      tone(BUZZER,
           shiftedFrequency(NOTE_FREQ[playingKey]));
    }
  }
}

void updateButtons() {
  unsigned long now = millis();

  for (int i = 0; i < 3; i++) {
    bool reading = digitalRead(BTN[i]) == LOW;

    if (reading != rawPressed[i]) {
      rawPressed[i] = reading;
      lastChange[i] = now;
    }

    if (now - lastChange[i] >= DEBOUNCE_MS) {
      pressed[i] = rawPressed[i];
    }
  }
}

void stopPlayback() {
  noTone(BUZZER);
  playMode = PLAY_NONE;
  playingKey = -1;
  noteGap = false;

  Serial.println("Da dung phat nhac!");
}

void startCurrentNote() {
  int originalFreq = 0;

  if (playMode == PLAY_BIRTHDAY) {
    originalFreq = MELODY[melodyIndex];
  } else if (playMode == PLAY_RECORDED) {
    originalFreq = recordedNotes[replayIndex];
  }

  int freq = shiftedFrequency(originalFreq);

  if (freq > 0) tone(BUZZER, freq);
  else noTone(BUZZER);

  if (playMode == PLAY_BIRTHDAY) {
    Serial.printf(
      "Melody note %d/%d | %d Hz\n",
      melodyIndex + 1, MELODY_LEN, freq
    );
  } else {
    Serial.printf(
      "Replay %d/%d | %d Hz\n",
      replayIndex + 1, recordedCount, freq
    );
  }

  noteStart = millis();
  noteGap = false;
}

void startBirthday() {
  noTone(BUZZER);
  playingKey = -1;
  playMode = PLAY_BIRTHDAY;
  melodyIndex = 0;

  Serial.println("Phat Happy Birthday... (millis)");
  startCurrentNote();
}

void startReplay() {
  if (recordedCount == 0) {
    Serial.println("Chua co not nao duoc ghi!");
    return;
  }

  noTone(BUZZER);
  playingKey = -1;
  playMode = PLAY_RECORDED;
  replayIndex = 0;

  Serial.printf(
    "Bat dau phat lai %d not...\n",
    recordedCount
  );

  startCurrentNote();
}

void updatePlayback() {
  if (playMode == PLAY_NONE) return;

  unsigned long now = millis();

  int duration = 350;

  if (playMode == PLAY_BIRTHDAY) {
    duration = DUR[melodyIndex];
  }

  if (!noteGap) {
    if (now - noteStart >= (unsigned long)duration) {
      noTone(BUZZER);
      noteGap = true;
      noteStart = now;
    }
  } else {
    if (now - noteStart >= GAP_MS) {
      if (playMode == PLAY_BIRTHDAY) {
        melodyIndex++;

        if (melodyIndex >= MELODY_LEN) {
          stopPlayback();
          Serial.println("Happy Birthday hoan tat!");
          return;
        }
      } else {
        replayIndex++;

        if (replayIndex >= recordedCount) {
          stopPlayback();
          Serial.println("Phat lai hoan tat!");
          return;
        }
      }

      startCurrentNote();
    }
  }
}

void toggleRecording() {
  if (!recording) {
    if (playMode != PLAY_NONE) stopPlayback();

    recording = true;
    recordedCount = 0;
    noTone(BUZZER);
    playingKey = -1;

    Serial.println("BAT DAU GHI NOT!");
  } else {
    recording = false;

    Serial.printf(
      "KET THUC GHI! Da luu %d not.\n",
      recordedCount
    );
  }
}

void recordNote(int key) {
  if (!recording) return;

  if (recordedCount < MAX_NOTES) {
    recordedNotes[recordedCount] = NOTE_FREQ[key];
    recordedCount++;

    Serial.printf(
      "REC %d/%d: %s (%d Hz)\n",
      recordedCount, MAX_NOTES,
      NOTE_NAME[key], NOTE_FREQ[key]
    );
  } else {
    recording = false;
    Serial.println("Bo nho day! Tu dong dung ghi.");
  }
}

void setup() {
  Serial.begin(115200);

  for (int i = 0; i < 3; i++) {
    pinMode(BTN[i], INPUT_PULLUP);
  }

  pinMode(POT_OCTAVE, INPUT);
  analogReadResolution(12);

  Serial.println("LAB 07 - Mini Piano");
  Serial.println("MR1: millis()");
  Serial.println("MR2: Bien tro quang tam");
  Serial.println("MR3: Ghi va phat lai not");
  Serial.println("DO + SOL = Happy Birthday");
  Serial.println("DO + MI = Bat/Tat ghi");
  Serial.println("MI + SOL = Phat lai");
  Serial.println("MI khi dang phat = Dung");

  updateOctave();
}

void loop() {
  updateOctave();
  updateButtons();

  int combo = getCombo();

  // Xu ly to hop nut
  if (combo != 0) {
    if (combo != previousCombo) {
      noTone(BUZZER);
      playingKey = -1;

      if (combo == 1) {
        toggleRecording();
      } else if (combo == 2) {
        if (recording) {
          Serial.println("Hay ket thuc ghi truoc!");
        } else {
          startBirthday();
        }
      } else if (combo == 3) {
        if (recording) {
          Serial.println("Hay ket thuc ghi truoc!");
        } else {
          startReplay();
        }
      }
    }

    previousCombo = combo;

    if (playMode != PLAY_NONE) {
      updatePlayback();
    }
  } else {
    previousCombo = 0;

    if (playMode != PLAY_NONE) {
      if (pressed[1] && !previousPressed[1]) {
        stopPlayback();
      } else {
        updatePlayback();
      }
    } else {
      int current = -1;

      for (int i = 0; i < 3; i++) {
        if (pressed[i]) {
          current = i;
          break;
        }
      }

      if (current != playingKey) {
        playingKey = current;

        if (current >= 0) {
          int freq = shiftedFrequency(NOTE_FREQ[current]);
          tone(BUZZER, freq);

          Serial.printf(
            "Not %s (%d Hz) | Octave=%+d\n",
            NOTE_NAME[current], freq, octaveShift
          );

          // Chi ghi khi bat dau nhan not
          if (!previousPressed[current]) {
            recordNote(current);
          }
        } else {
          noTone(BUZZER);
        }
      }
    }
  }

  for (int i = 0; i < 3; i++) {
    previousPressed[i] = pressed[i];
  }
}
