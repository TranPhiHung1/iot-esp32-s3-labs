# Lab 07 – Buzzer – mini piano và giai điệu

*Phần 1 – GPIO & ngoại vi cơ bản* · Board: **ESP32-S3-DevKitC-1** (Wokwi + PlatformIO)

## Mục tiêu

Tạo âm thanh tần số xác định bằng `tone()/noTone()`, biểu diễn giai điệu bằng mảng.

## Linh kiện & sơ đồ nối chân

| Linh kiện | Chân linh kiện | Nối tới ESP32-S3 |
|---|---|---|
| Buzzer | + / - | GPIO18 / GND |
| Nút nhấn DO | 1 / 2 | GPIO4 / GND (INPUT_PULLUP) |
| Nút nhấn MI | 1 / 2 | GPIO5 / GND (INPUT_PULLUP) |
| Nút nhấn SOL | 1 / 2 | GPIO6 / GND (INPUT_PULLUP) |

Nguồn: VCC → `3V3`, GND → `GND` (đã nối sẵn trong `diagram.json`).

## Cách chạy

1. Mở thư mục lab này bằng VS Code (đã cài PlatformIO IDE và Wokwi Simulator).
2. `PlatformIO: Build` (hoặc `pio run`).
3. `F1 → Wokwi: Start Simulator` – Wokwi đọc `wokwi.toml` và `diagram.json`.

## Kiến thức chính

Buzzer thụ động phát âm theo tần số xung vuông đưa vào. Mỗi nốt = (tần số, thời lượng). Nốt C4 = 262 Hz, E4 = 330 Hz, G4 = 392 Hz.

## Thử nghiệm trên Wokwi

Nhấn từng nút nghe nốt tương ứng; nhấn đồng thời DO + SOL để phát Happy Birthday.

## Bài tập mở rộng

1. Viết lại `playMelody()` không chặn (dùng `millis()`).
2. Thêm biến trở để chuyển quãng tám.
3. Ghi lại chuỗi phím đã nhấn rồi phát lại.
