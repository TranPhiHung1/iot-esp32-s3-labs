# Lab 02 – Đèn giao thông – máy trạng thái

*Phần 1 – GPIO & ngoại vi cơ bản* · Board: **ESP32-S3-DevKitC-1** (Wokwi + PlatformIO)

## Mục tiêu

Thiết kế chương trình theo máy trạng thái hữu hạn (FSM), quản lý thời gian bằng `millis()`.

## Linh kiện & sơ đồ nối chân

| Linh kiện | Chân linh kiện | Nối tới ESP32-S3 |
|---|---|---|
| LED red (led_r) | Anode (qua R 220Ω) | GPIO17 |
| LED yellow (led_y) | Anode (qua R 220Ω) | GPIO16 |
| LED green (led_g) | Anode (qua R 220Ω) | GPIO15 |

Nguồn: VCC → `3V3`, GND → `GND` (đã nối sẵn trong `diagram.json`).

## Cách chạy

1. Mở thư mục lab này bằng VS Code (đã cài PlatformIO IDE và Wokwi Simulator).
2. `PlatformIO: Build` (hoặc `pio run`).
3. `F1 → Wokwi: Start Simulator` – Wokwi đọc `wokwi.toml` và `diagram.json`.

## Kiến thức chính

Mỗi trạng thái (ĐỎ, XANH, VÀNG) có thời lượng riêng; chuyển trạng thái khi hết thời gian. FSM giúp code dễ mở rộng hơn chuỗi `delay()` lồng nhau.

## Thử nghiệm trên Wokwi

Quan sát chu trình ĐỎ 5 s → XANH 4 s → VÀNG 2 s; Serial in đếm ngược từng giây.

## Bài tập mở rộng

1. Thêm chế độ đêm: vàng nhấp nháy liên tục.
2. Thêm nút cho người đi bộ: nhấn thì rút ngắn đèn xanh còn 1 s.
3. Làm ngã tư 2 chiều với 6 LED.
