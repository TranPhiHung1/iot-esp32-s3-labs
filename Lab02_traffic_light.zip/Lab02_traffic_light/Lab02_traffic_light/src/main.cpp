/*
 * LAB 02 - Đèn giao thông bằng máy trạng thái (state machine)
 * LED đỏ 17, vàng 16, xanh 15. Không dùng delay().
 * da them nut nguoi di bo 18.
 */

#include <Arduino.h>

// Huong A
#define A_RED     17
#define A_YELLOW  16
#define A_GREEN   15

// Huong B
#define B_RED     4
#define B_YELLOW  5
#define B_GREEN   6

#define BUTTON_PIN 18

// FSM nga tu hai chieu
enum TrafficState {
  A_GREEN_B_RED,
  A_YELLOW_B_RED,
  A_RED_B_GREEN,
  A_RED_B_YELLOW
};

TrafficState state = A_GREEN_B_RED;

const unsigned long DURATION[] = {
  4000, 2000, 4000, 2000
};

const char* NAME[] = {
  "A XANH - B DO",
  "A VANG - B DO",
  "A DO - B XANH",
  "A DO - B VANG"
};

unsigned long stateStart = 0;
unsigned long programStart = 0;
unsigned long lastBlink = 0;

int lastSecShown = -1;

// Bai 1: Che do ban dem
bool nightMode = false;
bool yellowState = false;

const unsigned long NIGHT_START = 24000;
const unsigned long BLINK_INTERVAL = 500;

// Bai 2: Nut nguoi di bo
bool lastButtonReading = HIGH;
bool stableButtonState = HIGH;

unsigned long lastDebounceTime = 0;
const unsigned long DEBOUNCE_DELAY = 30;

unsigned long stateEndTime = 0;

// Dieu khien 6 LED
void apply(TrafficState s) {
  digitalWrite(A_RED,
    s == A_RED_B_GREEN || s == A_RED_B_YELLOW);
  digitalWrite(A_YELLOW, s == A_YELLOW_B_RED);
  digitalWrite(A_GREEN, s == A_GREEN_B_RED);

  digitalWrite(B_RED,
    s == A_GREEN_B_RED || s == A_YELLOW_B_RED);
  digitalWrite(B_YELLOW, s == A_RED_B_YELLOW);
  digitalWrite(B_GREEN, s == A_RED_B_GREEN);

  Serial.printf("\n==> %s\n", NAME[s]);
}

// Tat tat ca LED
void allOff() {
  digitalWrite(A_RED, LOW);
  digitalWrite(A_YELLOW, LOW);
  digitalWrite(A_GREEN, LOW);

  digitalWrite(B_RED, LOW);
  digitalWrite(B_YELLOW, LOW);
  digitalWrite(B_GREEN, LOW);
}

void setup() {
  Serial.begin(115200);

  pinMode(A_RED, OUTPUT);
  pinMode(A_YELLOW, OUTPUT);
  pinMode(A_GREEN, OUTPUT);

  pinMode(B_RED, OUTPUT);
  pinMode(B_YELLOW, OUTPUT);
  pinMode(B_GREEN, OUTPUT);

  pinMode(BUTTON_PIN, INPUT_PULLUP);

  programStart = millis();
  stateStart = programStart;
  stateEndTime = stateStart + DURATION[state];

  Serial.println("LAB 02 - NGA TU HAI CHIEU");
  Serial.println("FSM + NIGHT MODE + PEDESTRIAN");

  apply(state);
}

void loop() {
  unsigned long now = millis();

  // Doc nut va chong doi phim
  bool reading = digitalRead(BUTTON_PIN);

  if (reading != lastButtonReading) {
    lastDebounceTime = now;
  }

  if (now - lastDebounceTime >= DEBOUNCE_DELAY) {
    if (reading != stableButtonState) {
      stableButtonState = reading;

      // Rut ngan den xanh A hoac B con toi da 1s
      if (!nightMode &&
          stableButtonState == LOW &&
          (state == A_GREEN_B_RED ||
           state == A_RED_B_GREEN)) {

        unsigned long remaining =
          stateEndTime > now ? stateEndTime - now : 0;

        if (remaining > 1000) {
          stateEndTime = now + 1000;
          lastSecShown = -1;

          Serial.println(
            "\nNGUOI DI BO NHAN NUT!");
          Serial.println(
            "Den xanh con 1 giay");
        }
      }
    }
  }

  lastButtonReading = reading;

  // Chuyen sang che do dem sau 24s
  if (!nightMode &&
      now - programStart >= NIGHT_START) {

    nightMode = true;
    yellowState = false;
    lastBlink = now;

    allOff();

    Serial.println("\n=== CHE DO BAN DEM ===");
  }

  // Che do dem: hai den vang nhap nhay
  if (nightMode) {
    if (now - lastBlink >= BLINK_INTERVAL) {
      lastBlink = now;
      yellowState = !yellowState;

      digitalWrite(A_YELLOW, yellowState);
      digitalWrite(B_YELLOW, yellowState);

      Serial.println(yellowState ?
        "HAI DEN VANG BAT" :
        "HAI DEN VANG TAT");
    }
    return;
  }

  // Chuyen trang thai FSM
  if (now >= stateEndTime) {
    state = (TrafficState)((state + 1) % 4);

    stateStart = now;
    stateEndTime = now + DURATION[state];
    lastSecShown = -1;

    apply(state);
    return;
  }

  // Dem nguoc
  unsigned long remaining = stateEndTime - now;
  int remain = (remaining + 999) / 1000;

  if (remain != lastSecShown) {
    lastSecShown = remain;
    Serial.printf("  con %d s\n", remain);
  }
}


