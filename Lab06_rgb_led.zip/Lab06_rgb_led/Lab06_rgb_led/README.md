# Lab 06 – LED RGB – trộn màu và cầu vồng HSV

*Phần 1 – GPIO & ngoại vi cơ bản* · Board: **ESP32-S3-DevKitC-1** (Wokwi + PlatformIO)

## Mục tiêu

Điều khiển nhiều kênh PWM cùng lúc, chuyển đổi không gian màu HSV → RGB.

## Linh kiện & sơ đồ nối chân

| Linh kiện | Chân linh kiện | Nối tới ESP32-S3 |
|---|---|---|
| LED RGB (cathode chung) | R / G / B | GPIO17 / GPIO16 / GPIO15 |
| Biến trở độ sáng | SIG | GPIO1 (ADC1) |
| Nút nhấn MODE | 1 / 2 | GPIO4 / GND (INPUT_PULLUP) |

Nguồn: VCC → `3V3`, GND → `GND` (đã nối sẵn trong `diagram.json`).

## Cách chạy

1. Mở thư mục lab này bằng VS Code (đã cài PlatformIO IDE và Wokwi Simulator).
2. `PlatformIO: Build` (hoặc `pio run`).
3. `F1 → Wokwi: Start Simulator` – Wokwi đọc `wokwi.toml` và `diagram.json`.

## Kiến thức chính

LED RGB cathode chung: chân COM nối GND, mỗi kênh R/G/B là một LED riêng điều khiển bằng PWM 8 bit (0–255). HSV thuận tiện để tạo hiệu ứng cầu vồng.

## Thử nghiệm trên Wokwi

Nhấn MODE đổi qua 7 màu cố định rồi chế độ cầu vồng; xoay biến trở chỉnh độ sáng.

## Bài tập mở rộng

1. Nhập mã màu `#RRGGBB` qua Serial để đặt màu.
2. Thêm 3 biến trở chỉnh trực tiếp R, G, B.
3. Hiệu ứng “nhịp thở” theo màu đang chọn.
