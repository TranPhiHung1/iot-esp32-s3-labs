/*
 * LAB 06 - LED RGB: trộn màu bằng 3 kênh PWM
 * RGB (cathode chung): R=GPIO17, G=GPIO16, B=GPIO15
 * Nút GPIO4: đổi chế độ (bảng màu -> cầu vồng HSV). Biến trở GPIO1: độ sáng tổng.
 */

#include <Arduino.h>
#include <math.h>
#include <ctype.h>

// ===== GPIO =====
#define PIN_R 17
#define PIN_G 16
#define PIN_B 15

#define POT_BRIGHT 1
#define POT_R 2
#define POT_G 3
#define POT_B 5

#define BTN_MODE 4

// ===== PWM =====
const int PWM_FREQ = 1000;
const int PWM_BITS = 8;

// ===== MAU =====
struct Color {
  const char* name;
  uint8_t r, g, b;
};

const Color palette[] = {
  {"DO",        255,   0,   0},
  {"XANH LA",     0, 255,   0},
  {"XANH DUONG",  0,   0, 255},
  {"VANG",      255, 180,   0},
  {"TIM",       160,   0, 255},
  {"CYAN",        0, 255, 255},
  {"TRANG",     255, 255, 255}
};

const int COLOR_COUNT = 7;
const int MODE_RAINBOW = 7;
const int MODE_RGB_POT = 8;
const int MODE_HEX = 9;

int mode = 0;

uint8_t hexR = 255;
uint8_t hexG = 0;
uint8_t hexB = 0;

bool breathing = false;

float breathLevel = 1.0f;
int breathDirection = -1;

uint16_t hue = 0;

// ===== BUTTON =====
bool lastReading = HIGH;
bool stableButton = HIGH;

unsigned long lastDebounce = 0;
const unsigned long DEBOUNCE_MS = 50;

// ===== TIMING =====
unsigned long lastUpdate = 0;
unsigned long lastPrint = 0;
unsigned long lastHue = 0;

String serialBuffer = "";

// ===== PWM RGB =====
void setRGB(uint8_t r, uint8_t g, uint8_t b,
            float brightness) {

  brightness = constrain(
    brightness, 0.0f, 1.0f
  );

  ledcWrite(PIN_R, roundf(r * brightness));
  ledcWrite(PIN_G, roundf(g * brightness));
  ledcWrite(PIN_B, roundf(b * brightness));
}

// ===== HSV -> RGB =====
void hsvToRGB(uint16_t h,
              uint8_t &r,
              uint8_t &g,
              uint8_t &b) {

  float c = 1.0f;
  float x = 1.0f -
    fabsf(fmodf(h / 60.0f, 2.0f) - 1.0f);

  float rf = 0;
  float gf = 0;
  float bf = 0;

  if (h < 60) {
    rf = c; gf = x;
  } else if (h < 120) {
    rf = x; gf = c;
  } else if (h < 180) {
    gf = c; bf = x;
  } else if (h < 240) {
    gf = x; bf = c;
  } else if (h < 300) {
    rf = x; bf = c;
  } else {
    rf = c; bf = x;
  }

  r = roundf(rf * 255);
  g = roundf(gf * 255);
  b = roundf(bf * 255);
}

// ===== TEN CHE DO =====
const char* modeName() {

  if (mode < COLOR_COUNT) {
    return palette[mode].name;
  }

  if (mode == MODE_RAINBOW) {
    return "RAINBOW HSV";
  }

  if (mode == MODE_RGB_POT) {
    return "RGB POT";
  }

  return "HEX SERIAL";
}

// ===== DOC BIEN TRO =====
uint8_t readPot8(int pin) {

  int raw = analogRead(pin);

  return (uint8_t)map(
    raw, 0, 4095, 0, 255
  );
}

// ===== NUT MODE =====
void handleButton(unsigned long now) {

  bool reading = digitalRead(BTN_MODE);

  if (reading != lastReading) {
    lastDebounce = now;
    lastReading = reading;
  }

  if ((now - lastDebounce) >= DEBOUNCE_MS &&
      reading != stableButton) {

    stableButton = reading;

    if (stableButton == LOW) {

      // 7 mau + Rainbow + RGB POT
      mode = (mode + 1) % 9;

      Serial.printf(
        "MODE -> %s\n", modeName()
      );
    }
  }
}

// ===== CHUYEN KY TU HEX =====
int hexDigit(char c) {

  if (c >= '0' && c <= '9') {
    return c - '0';
  }

  c = toupper((unsigned char)c);

  if (c >= 'A' && c <= 'F') {
    return c - 'A' + 10;
  }

  return -1;
}

// ===== XU LY LENH SERIAL =====
void processCommand(String cmd) {

  cmd.trim();
  cmd.toUpperCase();

  if (cmd.length() == 7 &&
      cmd.charAt(0) == '#') {

    int values[6];

    for (int i = 0; i < 6; i++) {

      values[i] = hexDigit(
        cmd.charAt(i + 1)
      );

      if (values[i] < 0) {
        Serial.println(
          "LOI: Ma HEX khong hop le"
        );
        return;
      }
    }

    hexR = values[0] * 16 + values[1];
    hexG = values[2] * 16 + values[3];
    hexB = values[4] * 16 + values[5];

    mode = MODE_HEX;

    Serial.printf(
      "HEX OK: #%02X%02X%02X "
      "-> R=%d G=%d B=%d\n",
      hexR, hexG, hexB,
      hexR, hexG, hexB
    );

  } else if (cmd == "BREATH ON") {

    breathing = true;
    breathLevel = 0.0f;
    breathDirection = 1;

    Serial.println("BREATH: ON");

  } else if (cmd == "BREATH OFF") {

    breathing = false;
    breathLevel = 1.0f;

    Serial.println("BREATH: OFF");

  } else if (cmd == "HELP") {

    Serial.println("===== COMMANDS =====");
    Serial.println("#RRGGBB");
    Serial.println("BREATH ON");
    Serial.println("BREATH OFF");
    Serial.println("HELP");

  } else if (cmd.length() > 0) {

    Serial.println("Lenh khong hop le!");
    Serial.println("Nhap HELP de xem lenh");
  }
}

// ===== NHAN DU LIEU SERIAL =====
void handleSerial() {

  while (Serial.available() > 0) {

    char c = Serial.read();

    if (c == '\n' || c == '\r') {

      if (serialBuffer.length() > 0) {
        processCommand(serialBuffer);
        serialBuffer = "";
      }

    } else if (serialBuffer.length() < 64) {

      serialBuffer += c;

    } else {

      serialBuffer = "";
      Serial.println("Lenh qua dai!");
    }
  }
}

// ===== SETUP =====
void setup() {

  Serial.begin(115200);

  pinMode(BTN_MODE, INPUT_PULLUP);

  analogReadResolution(12);

  bool okR = ledcAttach(
    PIN_R, PWM_FREQ, PWM_BITS
  );

  bool okG = ledcAttach(
    PIN_G, PWM_FREQ, PWM_BITS
  );

  bool okB = ledcAttach(
    PIN_B, PWM_FREQ, PWM_BITS
  );

  Serial.println();
  Serial.println("LAB 06 - RGB FULL EXTENSIONS");

  if (!okR || !okG || !okB) {
    Serial.println(
      "LOI: Khoi tao PWM that bai!"
    );
  }

  Serial.println("MODE: 7 mau / HSV / RGB POT");
  Serial.println("HEX: nhap #RRGGBB");
  Serial.println("BREATH ON / BREATH OFF");
  Serial.println("HELP: xem lenh");

  Serial.printf(
    "Che do ban dau: %s\n",
    modeName()
  );
}

// ===== LOOP =====
void loop() {

  unsigned long now = millis();

  handleButton(now);
  handleSerial();

  if (now - lastUpdate < 20) {
    return;
  }

  lastUpdate = now;

  uint8_t r = 0;
  uint8_t g = 0;
  uint8_t b = 0;

  // 7 mau co dinh
  if (mode < COLOR_COUNT) {

    r = palette[mode].r;
    g = palette[mode].g;
    b = palette[mode].b;

  } else if (mode == MODE_RAINBOW) {

    if (now - lastHue >= 20) {
      lastHue = now;
      hue = (hue + 1) % 360;
    }

    hsvToRGB(hue, r, g, b);

  } else if (mode == MODE_RGB_POT) {

    r = readPot8(POT_R);
    g = readPot8(POT_G);
    b = readPot8(POT_B);

  } else if (mode == MODE_HEX) {

    r = hexR;
    g = hexG;
    b = hexB;
  }

  // Bien tro do sang chung
  float brightness =
    analogRead(POT_BRIGHT) / 4095.0f;

  // Hieu ung nhip tho
  if (breathing) {

    breathLevel += breathDirection * 0.01f;

    if (breathLevel >= 1.0f) {
      breathLevel = 1.0f;
      breathDirection = -1;
    }

    if (breathLevel <= 0.0f) {
      breathLevel = 0.0f;
      breathDirection = 1;
    }

    brightness *= breathLevel;
  }

  setRGB(r, g, b, brightness);

  if (now - lastPrint >= 1000) {

    lastPrint = now;

    Serial.printf(
      "MODE=%s | R=%d G=%d B=%d "
      "| Bright=%d%% | Breath=%s\n",
      modeName(),
      r, g, b,
      (int)(brightness * 100),
      breathing ? "ON" : "OFF"
    );
  }
}
